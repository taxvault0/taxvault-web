import React, { useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';

// Common Components
import Header from './components/common/Header';
import Sidebar from './components/common/Sidebar';
import DemoNav from './components/common/DemoNav';

// Auth Pages
import Login from './pages/auth/Login';
import LoginUser from './pages/auth/LoginUser';
import LoginCA from './pages/auth/LoginCA';
import Register from './pages/auth/Register';
import RoleSelect from './pages/auth/RoleSelect';
import ForgotPassword from './pages/auth/ForgotPassword';

// User Pages
import Dashboard from './pages/user/Dashboard';
import Receipts from './pages/user/Receipts';
import Mileage from './pages/user/Mileage';
import Documents from './pages/user/Documents';
import Profile from './pages/user/Profile';
import Settings from './pages/user/Settings';

// Gig Worker Pages
import GSTDashboard from './pages/gig/GSTDashboard';
import BusinessUseCalculator from './pages/gig/BusinessUseCalculator';
import T2125Form from './pages/gig/T2125Form';

// CA Pages
import CADashboard from './pages/ca/CADashboard';
import Clients from './pages/ca/Clients';
import ClientDetail from './pages/ca/ClientDetail';
import RegisterCA from './pages/ca/RegisterCA';

// Styles
import './styles/globals.css';

const PrivateRoute = ({ children, allowedRoles = ['user', 'ca'] }) => {
  const { isAuthenticated, user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="loader">Loading...</div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/" />;
  }

  if (!allowedRoles.includes(user?.role)) {
    return <Navigate to={user?.role === 'ca' ? '/ca/dashboard' : '/dashboard'} />;
  }

  return children;
};

const AppContent = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { isAuthenticated, user } = useAuth();

  // If not authenticated, show public routes
  if (!isAuthenticated) {
    return (
      <Routes>
        <Route path="/" element={<RoleSelect />} />
        <Route path="/login/user" element={<LoginUser />} />
        <Route path="/login/ca" element={<LoginCA />} />
        <Route path="/register/user" element={<Register />} />
        <Route path="/register/ca" element={<RegisterCA />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    );
  }

  // Authenticated routes
  return (
    <div className="min-h-screen bg-gray-50 flex">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      <div className="flex-1 flex flex-col">
        <Header onMenuClick={() => setSidebarOpen(true)} />
        
        <main className="flex-1 p-6">
          <div className="container mx-auto">
            <Routes>
              {/* User routes */}
              <Route path="/dashboard" element={
                <PrivateRoute allowedRoles={['user']}>
                  <Dashboard />
                </PrivateRoute>
              } />
              <Route path="/receipts" element={
                <PrivateRoute allowedRoles={['user']}>
                  <Receipts />
                </PrivateRoute>
              } />
              <Route path="/mileage" element={
                <PrivateRoute allowedRoles={['user']}>
                  <Mileage />
                </PrivateRoute>
              } />
              <Route path="/documents" element={
                <PrivateRoute allowedRoles={['user']}>
                  <Documents />
                </PrivateRoute>
              } />
              <Route path="/profile" element={
                <PrivateRoute>
                  <Profile />
                </PrivateRoute>
              } />
              <Route path="/settings" element={
                <PrivateRoute>
                  <Settings />
                </PrivateRoute>
              } />
              
              {/* Gig Worker routes */}
              <Route path="/gst-dashboard" element={
                <PrivateRoute allowedRoles={['user']}>
                  <GSTDashboard />
                </PrivateRoute>
              } />
              <Route path="/business-use-calculator" element={
                <PrivateRoute allowedRoles={['user']}>
                  <BusinessUseCalculator />
                </PrivateRoute>
              } />
              <Route path="/t2125-form" element={
                <PrivateRoute allowedRoles={['user']}>
                  <T2125Form />
                </PrivateRoute>
              } />
              
              {/* CA routes */}
              <Route path="/ca/dashboard" element={
                <PrivateRoute allowedRoles={['ca']}>
                  <CADashboard />
                </PrivateRoute>
              } />
              <Route path="/ca/clients" element={
                <PrivateRoute allowedRoles={['ca']}>
                  <Clients />
                </PrivateRoute>
              } />
              <Route path="/ca/clients/:id" element={
                <PrivateRoute allowedRoles={['ca']}>
                  <ClientDetail />
                </PrivateRoute>
              } />
              
              {/* Default redirect based on role */}
              <Route path="/" element={
                <Navigate to={user?.role === 'ca' ? '/ca/dashboard' : '/dashboard'} />
              } />
              <Route path="*" element={
                <Navigate to={user?.role === 'ca' ? '/ca/dashboard' : '/dashboard'} />
              } />
            </Routes>
          </div>
        </main>
      </div>
      
      {/* Demo navigation for development */}
      {process.env.NODE_ENV === 'development' && <DemoNav />}
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;