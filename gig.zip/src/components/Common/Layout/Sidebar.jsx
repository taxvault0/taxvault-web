import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  Receipt,
  FileText,
  MapPin,
  Settings,
  HelpCircle,
  LogOut,
  TrendingUp,
  Clock,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const Sidebar = ({ isOpen, onClose }) => {
  const { user, logout } = useAuth();

  const userNavItems = [
    { path: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/receipts', icon: Receipt, label: 'Receipts', badge: 3 },
    { path: '/mileage', icon: MapPin, label: 'Mileage' },
    { path: '/documents', icon: FileText, label: 'Documents' },
    { path: '/ca-access', icon: Users, label: 'CA Access' },
  ];

  const caNavItems = [
    { path: '/ca/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { 
      path: '/ca/clients', 
      icon: Users, 
      label: 'Clients',
      badge: 12
    },
    { 
      path: '/ca/reviews', 
      icon: Clock, 
      label: 'Pending Reviews',
      badge: 5,
      badgeColor: 'warning'
    },
    { path: '/ca/reports', icon: TrendingUp, label: 'Reports' },
  ];

  const bottomNavItems = [
    { path: '/settings', icon: Settings, label: 'Settings' },
    { path: '/help', icon: HelpCircle, label: 'Help & Support' },
  ];

  const navItems = user?.role === 'ca' ? caNavItems : userNavItems;

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-gray-600 bg-opacity-75 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`
          fixed top-0 left-0 h-full w-64 bg-white border-r border-gray-200 z-50
          transform transition-transform duration-300 ease-in-out
          lg:translate-x-0 lg:static lg:z-auto
          ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        `}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="h-16 flex items-center px-6 border-b border-gray-200">
            <span className="text-2xl font-bold text-primary-500">TaxVault</span>
          </div>

          {/* Navigation */}
          <nav className="flex-1 overflow-y-auto py-4">
            <div className="px-3 space-y-1">
              {navItems.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={({ isActive }) =>
                    `flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                      isActive
                        ? 'bg-primary-50 text-primary-700'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`
                  }
                  onClick={onClose}
                >
                  <item.icon size={18} className="mr-3" />
                  <span className="flex-1">{item.label}</span>
                  {item.badge && (
                    <span
                      className={`px-2 py-0.5 text-xs font-medium rounded-full ${
                        item.badgeColor === 'warning'
                          ? 'bg-warning-100 text-warning-600'
                          : 'bg-gray-100 text-gray-600'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </NavLink>
              ))}
            </div>

            {/* Bottom navigation */}
            <div className="absolute bottom-0 left-0 right-0 p-3 border-t border-gray-200 bg-white">
              <div className="space-y-1">
                {bottomNavItems.map((item) => (
                  <NavLink
                    key={item.path}
                    to={item.path}
                    className={({ isActive }) =>
                      `flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                        isActive
                          ? 'bg-primary-50 text-primary-700'
                          : 'text-gray-700 hover:bg-gray-100'
                      }`
                    }
                    onClick={onClose}
                  >
                    <item.icon size={18} className="mr-3" />
                    {item.label}
                  </NavLink>
                ))}
                <button
                  onClick={logout}
                  className="w-full flex items-center px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <LogOut size={18} className="mr-3" />
                  Logout
                </button>
              </div>
            </div>
          </nav>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;