import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Bell, 
  User, 
  Settings, 
  LogOut, 
  ChevronDown,
  Menu
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import Dropdown from '../ui/Dropdown';
import Avatar from '../ui/Avatar';

const Header = ({ onMenuClick }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-30">
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Left side */}
          <div className="flex items-center">
            <button
              onClick={onMenuClick}
              className="lg:hidden p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-primary-500"
              aria-label="Toggle menu"
            >
              <Menu size={24} />
            </button>
            <Link to="/dashboard" className="flex items-center ml-2 lg:ml-0">
              <span className="text-2xl font-bold text-blue-600">TaxVault</span>
              {user?.role === 'ca' && (
                <span className="ml-2 px-2 py-1 text-xs font-medium bg-purple-100 text-purple-800 rounded-full">
                  CA
                </span>
              )}
            </Link>
          </div>

          {/* Right side */}
          <div className="flex items-center space-x-4">
            {/* Notifications */}
            <button className="relative p-2 text-gray-400 hover:text-gray-500 hover:bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-primary-500">
              <Bell size={20} />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full ring-2 ring-white"></span>
            </button>

            {/* User dropdown */}
            <Dropdown
              trigger={
                <div className="flex items-center space-x-3 cursor-pointer p-1 hover:bg-gray-50 rounded-lg transition-colors duration-200">
                  <Avatar 
                    name={user?.name} 
                    src={user?.avatar}
                    size="sm"
                    className="h-8 w-8"
                  />
                  <div className="hidden md:block text-left">
                    <div className="text-sm font-medium text-gray-700">{user?.name || 'User'}</div>
                    <div className="text-xs text-gray-500">{user?.email}</div>
                  </div>
                </div>
              }
              align="right"
            >
              <div className="px-4 py-2 text-sm text-gray-700 border-b border-gray-100 md:hidden">
                <div className="font-medium">{user?.name || 'User'}</div>
                <div className="text-xs text-gray-500 truncate">{user?.email}</div>
              </div>
              
              <Dropdown.Item onClick={() => navigate('/profile')}>
                <User size={16} className="mr-2" />
                Profile
              </Dropdown.Item>
              
              <Dropdown.Item onClick={() => navigate('/settings')}>
                <Settings size={16} className="mr-2" />
                Settings
              </Dropdown.Item>
              
              <div className="border-t border-gray-100 my-1"></div>
              
              <Dropdown.Item onClick={handleLogout} danger>
                <LogOut size={16} className="mr-2" />
                Logout
              </Dropdown.Item>
            </Dropdown>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;