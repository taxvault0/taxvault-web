import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  HomeIcon, 
  UserGroupIcon, 
  DocumentIcon, 
  ReceiptPercentIcon,
  ChartBarIcon,
  ClockIcon,
  Cog6ToothIcon,
  QuestionMarkCircleIcon
} from '@heroicons/react/24/outline';
import { useAuth } from '../../context/AuthContext';

const Sidebar = () => {
  const { isCA } = useAuth();

  const caNavigation = [
    { name: 'Dashboard', href: '/ca/dashboard', icon: HomeIcon },
    { name: 'Clients', href: '/ca/clients', icon: UserGroupIcon },
    { name: 'Pending Reviews', href: '/ca/reviews', icon: ClockIcon, badge: 3 },
    { name: 'Reports', href: '/ca/reports', icon: ChartBarIcon },
    { name: 'Documents', href: '/ca/documents', icon: DocumentIcon },
  ];

  const userNavigation = [
    { name: 'Dashboard', href: '/dashboard', icon: HomeIcon },
    { name: 'Receipts', href: '/receipts', icon: ReceiptPercentIcon },
    { name: 'Mileage', href: '/mileage', icon: ChartBarIcon },
    { name: 'Documents', href: '/documents', icon: DocumentIcon },
    { name: 'CA Access', href: '/ca-access', icon: UserGroupIcon },
  ];

  const navigation = isCA ? caNavigation : userNavigation;

  return (
    <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0">
      <div className="flex-1 flex flex-col min-h-0 bg-white border-r border-gray-200">
        <div className="flex-1 flex flex-col pt-20 pb-4 overflow-y-auto">
          <nav className="mt-5 flex-1 px-2 space-y-1">
            {navigation.map((item) => (
              <NavLink
                key={item.name}
                to={item.href}
                className={({ isActive }) =>
                  `group flex items-center px-2 py-2 text-sm font-medium rounded-md ${
                    isActive
                      ? 'bg-primary-50 text-primary-700'
                      : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                  }`
                }
              >
                {({ isActive }) => (
                  <>
                    <item.icon
                      className={`mr-3 h-6 w-6 ${
                        isActive ? 'text-primary-500' : 'text-gray-400 group-hover:text-gray-500'
                      }`}
                    />
                    <span className="flex-1">{item.name}</span>
                    {item.badge && (
                      <span className="ml-3 inline-block py-0.5 px-2 text-xs font-medium rounded-full bg-warning-100 text-warning-600">
                        {item.badge}
                      </span>
                    )}
                  </>
                )}
              </NavLink>
            ))}
          </nav>

          {/* Bottom section */}
          <div className="mt-auto px-2 space-y-1">
            <NavLink
              to="/settings"
              className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900"
            >
              <Cog6ToothIcon className="mr-3 h-6 w-6 text-gray-400 group-hover:text-gray-500" />
              Settings
            </NavLink>
            <NavLink
              to="/help"
              className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900"
            >
              <QuestionMarkCircleIcon className="mr-3 h-6 w-6 text-gray-400 group-hover:text-gray-500" />
              Help & Support
            </NavLink>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;