import React from 'react';

const Avatar = ({ src, alt, fallback, className = '' }) => {
  return (
    <div className={`relative inline-flex items-center justify-center overflow-hidden rounded-full bg-gray-100 ${className}`}>
      {src ? (
        <img 
          src={src} 
          alt={alt || 'Avatar'} 
          className="h-full w-full object-cover"
        />
      ) : (
        <span className="font-medium text-gray-600">
          {fallback || 'U'}
        </span>
      )}
    </div>
  );
};

export default Avatar;