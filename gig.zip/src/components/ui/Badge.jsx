import React from 'react';

const Badge = ({ children, variant = 'info', className = '' }) => {
  const getVariantClass = () => {
    switch (variant) {
      case 'success':
        return 'badge-success';
      case 'warning':
        return 'badge-warning';
      case 'info':
        return 'badge-info';
      case 'gold':
        return 'badge-gold';
      default:
        return 'badge-info';
    }
  };

  return <span className={`badge ${getVariantClass()} ${className}`}>{children}</span>;
};

export default Badge;