import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

const StatsCard = ({
  title,
  value,
  icon: Icon,
  trend,
  trendValue,
  color = 'primary',
  className = '',
}) => {
  const getColorClass = () => {
    switch (color) {
      case 'primary':
        return 'stats-icon primary';
      case 'success':
        return 'stats-icon success';
      case 'warning':
        return 'stats-icon warning';
      case 'gold':
        return 'stats-icon gold';
      default:
        return 'stats-icon primary';
    }
  };

  return (
    <div className={`stats-card ${className}`}>
      <div className={getColorClass()}>
        <Icon size={24} />
      </div>
      <div className="stats-value">{value}</div>
      <div className="stats-label">{title}</div>
      {trend && (
        <div className="stats-trend">
          {trend === 'up' ? (
            <>
              <TrendingUp size={14} className="trend-up" />
              <span className="trend-up">+{trendValue}%</span>
            </>
          ) : (
            <>
              <TrendingDown size={14} className="trend-down" />
              <span className="trend-down">-{trendValue}%</span>
            </>
          )}
          <span className="text-xs text-gray-400 ml-1">vs last year</span>
        </div>
      )}
    </div>
  );
};

export default StatsCard;