import React, { forwardRef } from 'react';

const Input = forwardRef(
  (
    {
      label,
      type = 'text',
      error,
      hint,
      icon,
      className = '',
      id,
      required,
      ...props
    },
    ref
  ) => {
    const inputId = id || `input-${Math.random().toString(36).substr(2, 9)}`;

    return (
      <div className="input-group">
        {label && (
          <label htmlFor={inputId} className="input-label">
            {label}
            {required && <span className="text-warning ml-1">*</span>}
          </label>
        )}
        <div className="relative">
          {icon && <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">{icon}</span>}
          <input
            ref={ref}
            id={inputId}
            type={type}
            className={`input-field ${error ? 'error' : ''} ${icon ? 'pl-10' : ''} ${className}`}
            {...props}
          />
        </div>
        {error && <div className="input-error">{error}</div>}
        {hint && !error && <div className="input-hint">{hint}</div>}
      </div>
    );
  }
);

Input.displayName = 'Input';

export default Input;