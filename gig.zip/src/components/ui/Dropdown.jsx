import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const Dropdown = ({ trigger, children, align = 'right', className = '' }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className={`relative inline-block ${className}`} ref={dropdownRef}>
      <div 
        onClick={() => setIsOpen(!isOpen)} 
        className="cursor-pointer flex items-center"
      >
        {trigger}
        {isOpen ? (
          <ChevronUp className="ml-1 h-4 w-4 text-gray-500" />
        ) : (
          <ChevronDown className="ml-1 h-4 w-4 text-gray-500" />
        )}
      </div>
      
      {isOpen && (
        <div 
          className={`absolute mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-50 ${
            align === 'left' ? 'left-0' : 'right-0'
          }`}
        >
          <div className="py-1" role="menu">
            {children}
          </div>
        </div>
      )}
    </div>
  );
};

const DropdownItem = ({ children, onClick, danger = false, icon }) => {
  return (
    <button
      className={`w-full text-left px-4 py-2 text-sm flex items-center ${
        danger 
          ? 'text-red-600 hover:bg-red-50' 
          : 'text-gray-700 hover:bg-gray-100'
      } transition-colors duration-150 ease-in-out`}
      onClick={onClick}
      role="menuitem"
    >
      {icon && <span className="mr-2 h-4 w-4">{icon}</span>}
      {children}
    </button>
  );
};

Dropdown.Item = DropdownItem;

export default Dropdown;