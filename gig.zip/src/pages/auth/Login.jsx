import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { useAuth } from '../context/AuthContext';
import { EyeIcon, EyeSlashIcon } from '@heroicons/react/24/outline';

const Login = () => {
  const { login, verifyMfa } = useAuth();
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [mfaRequired, setMfaRequired] = useState(false);
  const [userId, setUserId] = useState(null);
  const [loading, setLoading] = useState(false);

  const formik = useFormik({
    initialValues: {
      email: '',
      password: '',
      mfaToken: ''
    },
    validationSchema: Yup.object({
      email: Yup.string()
        .email('Invalid email address')
        .required('Email is required'),
      password: Yup.string()
        .required('Password is required')
        .min(8, 'Password must be at least 8 characters'),
      mfaToken: Yup.string()
        .when('$mfaRequired', {
          is: true,
          then: (schema) => schema.required('MFA token is required').length(6, 'MFA token must be 6 digits')
        })
    }),
    onSubmit: async (values) => {
      setLoading(true);
      
      if (mfaRequired) {
        const result = await verifyMfa(userId, values.mfaToken);
        if (result.success) {
          navigate('/dashboard');
        }
      } else {
        const result = await login(values.email, values.password);
        if (result.success) {
          navigate('/dashboard');
        } else if (result.requiresMfa) {
          setMfaRequired(true);
          setUserId(result.userId);
        }
      }
      
      setLoading(false);
    }
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 to-gray-100 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        {/* Logo */}
        <div className="text-center">
          <h1 className="text-4xl font-bold text-primary-600">TaxVault</h1>
          <h2 className="mt-2 text-2xl font-semibold text-gray-900">Welcome Back</h2>
          <p className="mt-2 text-sm text-gray-600">
            {mfaRequired ? 'Enter your MFA code' : 'Sign in to your account'}
          </p>
        </div>

        {/* Form */}
        <div className="bg-white py-8 px-4 shadow-xl rounded-lg sm:px-10">
          <form className="space-y-6" onSubmit={formik.handleSubmit}>
            {!mfaRequired ? (
              <>
                {/* Email */}
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                    Email address
                  </label>
                  <div className="mt-1">
                    <input
                      id="email"
                      name="email"
                      type="email"
                      autoComplete="email"
                      className="input-field"
                      value={formik.values.email}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    {formik.touched.email && formik.errors.email && (
                      <p className="error-text">{formik.errors.email}</p>
                    )}
                  </div>
                </div>

                {/* Password */}
                <div>
                  <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                    Password
                  </label>
                  <div className="mt-1 relative">
                    <input
                      id="password"
                      name="password"
                      type={showPassword ? 'text' : 'password'}
                      autoComplete="current-password"
                      className="input-field pr-10"
                      value={formik.values.password}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    <button
                      type="button"
                      className="absolute inset-y-0 right-0 pr-3 flex items-center"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? (
                        <EyeSlashIcon className="h-5 w-5 text-gray-400" />
                      ) : (
                        <EyeIcon className="h-5 w-5 text-gray-400" />
                      )}
                    </button>
                    {formik.touched.password && formik.errors.password && (
                      <p className="error-text">{formik.errors.password}</p>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <input
                      id="remember-me"
                      name="remember-me"
                      type="checkbox"
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                    />
                    <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-900">
                      Remember me
                    </label>
                  </div>

                  <div className="text-sm">
                    <Link to="/forgot-password" className="font-medium text-primary-600 hover:text-primary-500">
                      Forgot your password?
                    </Link>
                  </div>
                </div>
              </>
            ) : (
              // MFA Token Input
              <div>
                <label htmlFor="mfaToken" className="block text-sm font-medium text-gray-700">
                  MFA Verification Code
                </label>
                <div className="mt-1">
                  <input
                    id="mfaToken"
                    name="mfaToken"
                    type="text"
                    maxLength="6"
                    placeholder="000000"
                    className="input-field text-center text-2xl tracking-widest"
                    value={formik.values.mfaToken}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.touched.mfaToken && formik.errors.mfaToken && (
                    <p className="error-text">{formik.errors.mfaToken}</p>
                  )}
                </div>
                <p className="mt-2 text-xs text-gray-500">
                  Enter the 6-digit code from your authenticator app
                </p>
              </div>
            )}

            {/* Submit Button */}
            <div>
              <button
                type="submit"
                disabled={loading}
                className="w-full btn-primary"
              >
                {loading ? (
                  <div className="flex items-center justify-center">
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                    <span className="ml-2">
                      {mfaRequired ? 'Verifying...' : 'Signing in...'}
                    </span>
                  </div>
                ) : (
                  mfaRequired ? 'Verify Code' : 'Sign In'
                )}
              </button>
            </div>
          </form>

          {/* Sign up link */}
          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">
                  New to TaxVault?
                </span>
              </div>
            </div>

            <div className="mt-6">
              <Link
                to="/register"
                className="w-full inline-flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
              >
                Create an account
              </Link>
            </div>
          </div>
        </div>

        {/* Security badge */}
        <div className="text-center">
          <p className="text-xs text-gray-500">
            🔒 Secured with bank-level encryption
          </p>
          <p className="text-xs text-gray-500 mt-1">
            🇨🇦 Your data stays in Canada
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;