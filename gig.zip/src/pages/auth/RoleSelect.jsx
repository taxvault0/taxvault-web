import React from 'react';
import { Link } from 'react-router-dom';
import { User, Briefcase, ArrowRight, Shield, Star } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';

const RoleSelect = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 to-gray-100 flex items-center justify-center py-12 px-4">
      <div className="max-w-4xl w-full">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-primary-600">TaxVault</h1>
          <h2 className="text-2xl font-semibold text-gray-800 mt-4">Welcome to TaxVault Canada</h2>
          <p className="text-gray-600 mt-2">Choose your account type to continue</p>
        </div>

        {/* Role Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* User Card */}
          <Card className="hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
            <Card.Body className="p-8">
              <div className="flex flex-col items-center text-center">
                <div className="w-20 h-20 bg-primary-100 rounded-full flex items-center justify-center mb-6">
                  <User size={40} className="text-primary-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-2">Individual Taxpayer</h3>
                <p className="text-gray-600 mb-6">
                  For gig workers, employees, self-employed professionals, and small business owners
                </p>
                
                {/* Features */}
                <div className="space-y-3 w-full mb-8">
                  <div className="flex items-center text-sm text-gray-600">
                    <Shield size={16} className="text-primary-500 mr-2" />
                    <span>Snap & store receipts year-round</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <Shield size={16} className="text-primary-500 mr-2" />
                    <span>Auto-track mileage with GPS</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <Shield size={16} className="text-primary-500 mr-2" />
                    <span>Share securely with your CA</span>
                  </div>
                </div>

                {/* Actions */}
                <div className="w-full space-y-3">
                  <Link to="/login/user" className="w-full">
                    <Button variant="primary" fullWidth>
                      Login as User
                      <ArrowRight size={16} className="ml-2" />
                    </Button>
                  </Link>
                  <Link to="/register/user" className="w-full">
                    <Button variant="outline" fullWidth>
                      Create User Account
                    </Button>
                  </Link>
                </div>
              </div>
            </Card.Body>
          </Card>

          {/* CA Card */}
          <Card className="hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border-2 border-primary-200 relative overflow-hidden">
            <div className="absolute top-0 right-0 bg-primary-500 text-white px-4 py-1 rounded-bl-lg text-sm font-medium">
              Professional
            </div>
            <Card.Body className="p-8">
              <div className="flex flex-col items-center text-center">
                <div className="w-20 h-20 bg-primary-100 rounded-full flex items-center justify-center mb-6">
                  <Briefcase size={40} className="text-primary-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-2">Chartered Accountant</h3>
                <p className="text-gray-600 mb-6">
                  For accounting professionals and firms managing multiple clients
                </p>
                
                {/* Features */}
                <div className="space-y-3 w-full mb-8">
                  <div className="flex items-center text-sm text-gray-600">
                    <Star size={16} className="text-primary-500 mr-2" />
                    <span>Manage all clients in one dashboard</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <Star size={16} className="text-primary-500 mr-2" />
                    <span>Review & verify client documents</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <Star size={16} className="text-primary-500 mr-2" />
                    <span>Professional verification & credentials</span>
                  </div>
                </div>

                {/* Actions */}
                <div className="w-full space-y-3">
                  <Link to="/login/ca" className="w-full">
                    <Button variant="secondary" fullWidth>
                      Login as CA
                      <ArrowRight size={16} className="ml-2" />
                    </Button>
                  </Link>
                  <Link to="/register/ca" className="w-full">
                    <Button variant="outline" fullWidth>
                      Register as CA
                    </Button>
                  </Link>
                </div>
              </div>
            </Card.Body>
          </Card>
        </div>

        {/* Security Note */}
        <div className="text-center mt-12">
          <p className="text-sm text-gray-500 flex items-center justify-center">
            <Shield size={16} className="mr-2" />
            Bank-level encryption • Canadian data residency • PIPEDA compliant
          </p>
        </div>
      </div>
    </div>
  );
};

export default RoleSelect;