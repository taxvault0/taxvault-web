import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Receipt, 
  MapPin, 
  FileText, 
  TrendingUp,
  Camera,
  DollarSign,
  Car,
  CalendarClock,
  ChevronRight
} from 'lucide-react';
import Card from '../components/ui/Card';
import StatsCard from '../components/ui/StatsCard';
import Badge from '../components/ui/Badge';

const Dashboard = () => {
  const recentReceipts = [
    { id: 1, vendor: 'Shell', amount: 45.23, date: '2024-03-15', category: 'Fuel', status: 'verified' },
    { id: 2, vendor: 'Canadian Tire', amount: 123.45, date: '2024-03-14', category: 'Maintenance', status: 'pending' },
    { id: 3, vendor: 'Amazon', amount: 89.99, date: '2024-03-12', category: 'Office Supplies', status: 'verified' },
  ];

  const recentTrips = [
    { id: 1, purpose: 'business', distance: 23.4, date: '2024-03-15', start: 'Home', end: 'Client Office' },
    { id: 2, purpose: 'commute', distance: 12.1, date: '2024-03-14', start: 'Home', end: 'Work' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-500 mt-1">Welcome back! Here's your tax summary.</p>
        </div>
        <Link to="/receipts/new" className="btn-primary flex items-center">
          <Camera size={16} className="mr-2" />
          Scan Receipt
        </Link>
      </div>

      {/* Stats Grid - THIS SECTION SHOULD APPEAR ONLY ONCE */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Total Income"
          value="$42,350"
          icon={TrendingUp}
          trend="up"
          trendValue={12}
          color="primary"
        />
        <StatsCard
          title="Total Expenses"
          value="$12,445"
          icon={Receipt}
          trend="down"
          trendValue={5}
          color="warning"
        />
        <StatsCard
          title="Net Income"
          value="$29,905"
          icon={DollarSign}
          trend="up"
          trendValue={8}
          color="success"
        />
        <StatsCard
          title="Mileage Tracked"
          value="2,345 km"
          icon={Car}
          trend="up"
          trendValue={23}
          color="gold"
        />
      </div>

      {/* Quick Actions */}
      <Card>
        <Card.Header>
          <h3 className="font-semibold text-gray-900">Quick Actions</h3>
        </Card.Header>
        <Card.Body>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Link to="/receipts/new" className="flex flex-col items-center p-4 bg-gray-50 rounded-lg hover:bg-primary-50 transition-colors">
              <Camera size={24} className="text-primary-500 mb-2" />
              <span className="text-sm font-medium">Scan Receipt</span>
            </Link>
            <Link to="/mileage/track" className="flex flex-col items-center p-4 bg-gray-50 rounded-lg hover:bg-primary-50 transition-colors">
              <MapPin size={24} className="text-primary-500 mb-2" />
              <span className="text-sm font-medium">Track Mileage</span>
            </Link>
            <Link to="/documents/upload" className="flex flex-col items-center p-4 bg-gray-50 rounded-lg hover:bg-primary-50 transition-colors">
              <FileText size={24} className="text-primary-500 mb-2" />
              <span className="text-sm font-medium">Upload Document</span>
            </Link>
            <Link to="/profile" className="flex flex-col items-center p-4 bg-gray-50 rounded-lg hover:bg-primary-50 transition-colors">
              <TrendingUp size={24} className="text-primary-500 mb-2" />
              <span className="text-sm font-medium">View Profile</span>
            </Link>
          </div>
        </Card.Body>
      </Card>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Receipts */}
        <Card>
          <Card.Header className="flex items-center justify-between">
            <h3 className="font-semibold text-gray-900">Recent Receipts</h3>
            <Link to="/receipts" className="text-sm text-primary-500 hover:text-primary-600 flex items-center">
              View All
              <ChevronRight size={16} className="ml-1" />
            </Link>
          </Card.Header>
          <Card.Body>
            <div className="space-y-3">
              {recentReceipts.map((receipt) => (
                <Link 
                  key={receipt.id} 
                  to={`/receipts/${receipt.id}`}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <div className="flex items-center">
                    <Receipt size={20} className="text-gray-400 mr-3" />
                    <div>
                      <div className="font-medium text-gray-900">{receipt.vendor}</div>
                      <div className="text-xs text-gray-500">{receipt.date}</div>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <span className="font-semibold text-gray-900 mr-3">${receipt.amount.toFixed(2)}</span>
                    <Badge variant={receipt.status === 'verified' ? 'success' : 'warning'}>
                      {receipt.status}
                    </Badge>
                  </div>
                </Link>
              ))}
            </div>
          </Card.Body>
        </Card>

        {/* Recent Trips */}
        <Card>
          <Card.Header className="flex items-center justify-between">
            <h3 className="font-semibold text-gray-900">Recent Trips</h3>
            <Link to="/mileage" className="text-sm text-primary-500 hover:text-primary-600 flex items-center">
              View All
              <ChevronRight size={16} className="ml-1" />
            </Link>
          </Card.Header>
          <Card.Body>
            <div className="space-y-3">
              {recentTrips.map((trip) => (
                <div key={trip.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <MapPin size={20} className="text-gray-400 mr-3" />
                    <div>
                      <div className="font-medium text-gray-900">{trip.start} → {trip.end}</div>
                      <div className="text-xs text-gray-500">{trip.date} • {trip.distance} km</div>
                    </div>
                  </div>
                  <Badge variant={trip.purpose === 'business' ? 'success' : 'info'}>
                    {trip.purpose}
                  </Badge>
                </div>
              ))}
            </div>
          </Card.Body>
        </Card>
      </div>

      {/* Upcoming Deadline */}
      <Card className="bg-warning-50 border-warning-200">
        <Card.Body>
          <div className="flex items-center">
            <CalendarClock className="text-warning-500 mr-4" size={24} />
            <div className="flex-1">
              <h4 className="font-semibold text-warning-700">Tax Filing Deadline Approaching</h4>
              <p className="text-sm text-warning-600">April 30, 2025 • 45 days left</p>
            </div>
            <Link to="/documents" className="btn-outline btn-sm">
              Prepare Now
            </Link>
          </div>
        </Card.Body>
      </Card>

      {/* Canadian Data Badge */}
      <div className="flex items-center justify-center text-xs text-gray-400">
        <span className="mr-1">🍁</span>
        Your data is securely stored on Canadian servers
      </div>
    </div>
  );
};

export default Dashboard;