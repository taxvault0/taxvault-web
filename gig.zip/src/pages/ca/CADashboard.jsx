import React from 'react';
import { useQuery } from 'react-query';
import { Link } from 'react-router-dom';
import { 
  UserGroupIcon, 
  DocumentIcon, 
  ClockIcon,
  CheckCircleIcon,
  ExclamationTriangleIcon,
  ArrowTrendingUpIcon
} from '@heroicons/react/24/outline';
import { caAPI } from '../../services/api';
import StatsCard from '../../components/Common/StatsCard';
import ClientTable from '../../components/Common/ClientTable';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const CADashboard = () => {
  const { data: clients, isLoading: clientsLoading } = useQuery(
    'ca-clients',
    () => caAPI.getClients({ limit: 5 }).then(res => res.data)
  );

  const { data: pendingReviews } = useQuery(
    'pending-reviews',
    () => caAPI.getPendingReviews().then(res => res.data)
  );

  const { data: activity } = useQuery(
    'ca-activity',
    () => caAPI.getActivity().then(res => res.data)
  );

  // Sample data for charts
  const chartData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        label: 'Documents Processed',
        data: [65, 78, 92, 85, 110, 95],
        backgroundColor: 'rgba(0, 90, 156, 0.5)',
        borderColor: '#005A9C',
        borderWidth: 1,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
      },
    },
  };

  const stats = [
    {
      title: 'Total Clients',
      value: clients?.total || 0,
      change: 12,
      trend: 'up',
      icon: UserGroupIcon
    },
    {
      title: 'Pending Reviews',
      value: pendingReviews?.length || 0,
      change: 5,
      trend: 'up',
      icon: ClockIcon
    },
    {
      title: 'Ready to File',
      value: clients?.readyCount || 0,
      change: 8,
      trend: 'up',
      icon: CheckCircleIcon
    },
    {
      title: 'Needs Attention',
      value: clients?.attentionCount || 0,
      change: 3,
      trend: 'down',
      icon: ExclamationTriangleIcon
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">CA Dashboard</h1>
        <p className="mt-1 text-sm text-gray-500">
          Welcome back! Here's what's happening with your clients today.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <StatsCard key={stat.title} {...stat} />
        ))}
      </div>

      {/* Charts and Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Monthly Activity</h3>
          <div className="h-64">
            <Bar data={chartData} options={chartOptions} />
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Recent Activity</h3>
          <div className="space-y-4">
            {activity?.slice(0, 5).map((item, index) => (
              <div key={index} className="flex items-start space-x-3">
                <div className="flex-shrink-0">
                  <div className="h-8 w-8 rounded-full bg-primary-100 flex items-center justify-center">
                    <DocumentIcon className="h-4 w-4 text-primary-600" />
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-gray-900">{item.description}</p>
                  <p className="text-xs text-gray-500">{item.time}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4">
            <Link to="/ca/activity" className="text-sm text-primary-600 hover:text-primary-700 font-medium">
              View all activity →
            </Link>
          </div>
        </div>
      </div>

      {/* Recent Clients */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium text-gray-900">Recent Clients</h3>
          <Link to="/ca/clients" className="text-sm text-primary-600 hover:text-primary-700 font-medium">
            View all clients →
          </Link>
        </div>
        {clientsLoading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500 mx-auto"></div>
          </div>
        ) : (
          <ClientTable clients={clients?.data || []} />
        )}
      </div>

      {/* Pending Reviews */}
      {pendingReviews && pendingReviews.length > 0 && (
        <div className="bg-warning-50 border border-warning-200 rounded-xl p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <ClockIcon className="h-5 w-5 text-warning-400" />
            </div>
            <div className="ml-3 flex-1">
              <h3 className="text-sm font-medium text-warning-800">
                Pending Reviews
              </h3>
              <div className="mt-2 text-sm text-warning-700">
                <p>
                  You have {pendingReviews.length} documents waiting for review.
                </p>
              </div>
              <div className="mt-4">
                <Link
                  to="/ca/reviews"
                  className="text-sm font-medium text-warning-800 hover:text-warning-900"
                >
                  View pending reviews →
                </Link>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CADashboard;